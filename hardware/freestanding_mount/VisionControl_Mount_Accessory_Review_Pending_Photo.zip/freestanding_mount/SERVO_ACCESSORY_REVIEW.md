# Supplied servo accessories — review pending photo and measurements

User confirmation, 2026-11-07: the two Miuzei MG90S servos have arrived with
**plastic horns and mounting screws**. Use those horns as the spline connections;
adapt the printed interfaces to the selected horns. No replacement horn or printed
spline is specified. The new accessory photo was not available in this message.
Horn types, accessory counts, screw identities and exact sizes have therefore
**not been visually identified**. Earlier webcam photographs are not servo evidence.

This review changes documentation and the BOM only. The existing architecture,
base, target 140 mm optical height and resin geometry remain unchanged. The camera
mounting hole stays disabled for owner drilling. No new CAD sweep was necessary;
the earlier kernel checks apply to the unchanged provisional model, not a measured
fit with the newly arrived accessories. Physical compatibility remains pending.

## What the current interface requires

| Interface | Existing CAD assumption | Required physical check |
|---|---|---|
| Stock horn selection | One usable horn per axis; type unspecified | Photograph all supplied horn shapes on both faces and identify the selected pair |
| Attachment-hole pattern | Two opposed holes, radius 8 mm from shaft centre (16 mm separation) | Measure X/Y coordinates of each usable hole from the hub centre; do not substitute an adjacent-hole pitch for the radius |
| Hole diameter | 2.3 mm clearance in printed parts | Measure stock-hole diameter and intended screw shank/thread; these are not verified M2 holes |
| Horn outline | Circular reference envelope, radius 11 mm | Measure full arm length, width and asymmetric outline; the reference disk is not a reproduction of the supplied horn |
| Horn axial fit | Nominal 2 mm thickness against a flat printed mating face | Measure thickness at selected holes and hub projection on both faces; check whether the hub needs a printed relief |
| Centre screw access | 7 mm access diameter | Identify the actual supplied centre screw; check head/driver clearance and seating depth |
| Pan attachment | 4 mm rotor + 3 mm hub = 7 mm printed grip | Check supplied screw reach through the printed grip plus actual horn/washer stack; ensure clearance to the servo case and journal |
| Tilt attachment | 6 mm printed adapter | Check supplied screw reach and protrusion; prevent contact with the flange, servo or centre screw |
| Servo tabs | 28 mm hole pitch; 2.3 mm holes; nominal 2 mm thickness | Measure each unit's tab outline, thickness, hole positions and edge distances |
| Servo body coupon | 23.4 × 12.8 mm aperture | Measure actual body where it passes through the mounting plate; confirm connector/wire access |
| Shaft position | 5.3 mm offset in one mounting-plane direction; other offset assumed zero | Measure shaft centre in both directions relative to the body/tab datums |
| Shaft/horn height | Nominal 5 mm shaft projection | Measure the installed horn mating face from the servo mounting datum; verify the thrust-washer and tilt-axis stacks |

`HornHoleRadius`, `HornHoleCount`, `HornHoleDiameter`, `HornRadius`,
`HornThickness`, `ServoTabPitch`, `ServoTabHole`, `ServoTabThickness`,
`ServoTabEndWidth`, `ServoShaftOffset`, `ServoShaftProjection` and fit clearances
remain provisional parameters. They have not been replaced with guesses from a photo.

The current hole generator describes an equally spaced circular pattern. A single-arm
horn with two holes along one arm, an asymmetric cross, or unequal hole radii needs
explicit measured hole coordinates in the printed interface. Changing a radius alone
cannot represent those patterns. Choose the actual horn first; then update only the
affected printed interface and validate its swept outline. Preserve the supplied
horn rather than drilling it to match the current CAD. A double-arm or cross horn
may provide opposed holes **if one is actually supplied and measured**.

## Sort the included screws by function

Keep each servo's accessories together. Presence of mounting screws does not establish
that every fastener required by this assembly is supplied.

1. **Horn centre retention:** use the matching supplied centre screw once identified.
   Record under-head length, head diameter and thread; do not substitute a tab screw.
2. **Servo tab attachment:** identify which supplied screws are intended for tabs and
   measure their diameter, length and thread form. They may not be machine screws
   suitable for M2 nuts. Do not force a coarse/self-tapping screw into the existing
   resin clearance holes or invent a compatible nut size.
3. **Horn-to-printed-part attachment:** check whether any included screws are suitable
   and long enough. The BOM's M2 × 12 entries are conditional candidates, not verified
   supplied hardware. Do not assume the servo's centre screw can perform this job.

For a machine screw and nut, required under-head length includes printed grip,
actual horn thickness, washers and full nut engagement; any exposed tip must clear
the mechanism. For a screw intended to engage a plastic horn, measure the remaining
engagement after the printed grip and washer: it must suit the stock horn and must
not bottom, split it or protrude into the servo. Obtain the intended engagement from
the accessory design/manufacturer rather than choosing an arbitrary turn count.
If the included screws are too short, resolve fastener length or the printed seat
after measurement; do not thin a loaded adapter or countersink it speculatively.

The thrust washer carries pan weight; the horn transmits torque and retains the
rotor. Confirm that the fitted stock horn does not preload the servo shaft axially.
On tilt, the opposite pivot remains essential; tightening horn screws must not pull
the cradle sideways or bind the passive support.

## Existing fit coupon

Use `output_verified/stl/ServoFitCoupon.stl` for the initial body/tab check. No new
measurements presently justify a different coupon, so it has not been regenerated
or relabelled as matched to the purchased unit. Its aperture is 23.4 × 12.8 mm,
tab-hole pitch 28 mm and holes 2.3 mm. Do not force an actual servo into it.
It cannot validate horn geometry, shaft height or the complete screw stack.

Once dimensions are supplied, update the affected parameters and generate a fresh
coupon/output directory. If a horn pattern or hub relief changes, add a small test
piece reproducing that actual printed interface before committing to the assembly
print. Rerun the CAD checks for every changed geometry.

## Blank camera plate and drilling later

The existing plate is 90 × 52 × 4 mm, removable with four M3 fasteners at
X ±34 / Y ±18 mm. The centre remains solid: `CameraHoleEnabled=false`.
Keeping the full 4 mm thickness and the existing cradle support is appropriate
for this preliminary drilling plan; no extra lightening has been added. Actual
drilled-part strength still requires a fit/load check after curing and assembly.

The cradle below it has a **24 × 20 mm centred access opening**. Before drilling,
mark the real insert location with the camera in its intended centred pose. Ensure
the complete underside screw-head/washer footprint fits inside that opening;
otherwise it may prevent the plate seating on the cradle. For a circular footprint
of diameter D, its centre must satisfy `abs(X) + D/2 < 12` and
`abs(Y) + D/2 < 10` mm, with additional practical clearance. X/Y are measured from
the plate centre. For example, a 12 mm footprint allows less than ±6 mm X and
±4 mm Y before adding that clearance. This is a geometric access limit, not a
recommendation to purchase a 12 mm washer.

If the measured insert requires a location outside that usable region, stop and
adjust the printed access geometry before printing the full cradle; shifting the
camera also changes balance and motion clearance. Remove the plate for marking and
drilling, support it flat on sacrificial backing, clamp it without bending it and
drill without the camera attached. Use controlled light feed, avoid overheating
or aggressive countersinking, deburr gently and reject cracking/chipping. Preserve
the four existing fastener lands and enough surrounding material for the actual
head/washer. Do not use a screw's threads to cut a hole through cured resin.

Select the camera screw only after confirming the insert diameter, pitch and usable
depth. The 1/4-20 CAD value remains an unused candidate. Account for the 4 mm plate,
pad/washer thickness and required engagement without bottoming in the insert. Check
that the plate seats flat and the folding mechanism remains free before load testing.

## Measurements to send next

- Reattach the accessory photo; include both sides of each horn and separate the
  screw types so they can be identified. A photo establishes shape, not precise size.
- For each selected horn: overall outline, two or more hole-centre coordinates from
  the shaft centre, hole diameter, thickness and hub projection on both sides.
- For each servo: tab-hole pitch/offsets/diameter, tab thickness, and shaft-centre X/Y
  plus installed-horn mating-face height relative to the mounting datum.
- For each screw type: quantity, head diameter, under-head length, thread diameter
  and whether it is a machine or self-tapping thread; thread pitch if measurable.
- For the manual camera mounting: planned insert location and underside head/washer
  footprint, so the access opening and balance can be checked before final printing.

The confirmed 1 litre resin purchase does not require further weight optimization.
Keep the current base and architecture; prioritize accessory fit and practical assembly.
